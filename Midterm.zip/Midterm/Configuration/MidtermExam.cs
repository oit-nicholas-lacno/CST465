namespace Midterm;
public class MidtermExam
{
    public List<TestQuestion> Questions { get;set; } = new List<TestQuestion>();
}