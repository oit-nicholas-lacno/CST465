using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
namespace Midterm;

//TODO:  Is something missing here? 
public class MidtermExamController : Controller
{
    private readonly MidtermExam _Exam;
    private readonly IConfiguration _Config;
    
    public MidtermExamController(IConfiguration conf, IOptions<MidtermExam> exam)
    {
        _Exam = exam.Value;
    }
    [Route("")]
    [HttpGet]
    public IActionResult Index()
    {
        return View();
    }
    
    [Route("TakeTest")]
    [HttpGet]
    public IActionResult TakeTest()
    {
        List<TestQuestionModel> questionModels = GetQuestionModels();
        return View(questionModels);
    }
    [Route("SubmitTest")]
    [HttpPost]
    public IActionResult TakeTest(List<TestQuestionModel> model)
    {
        List<TestQuestionModel> questionModels = GetQuestionModels();
        //TODO: At this point you will only have the raw answers in the model.  Questions did not get posted back.
        //You will need to get the questions again from GetQuestionModels(), then set the answer values on the retrieved list by
        //  matching the two lists based on ID
        if(!ModelState.IsValid)
        {
            return View(questionModels);
        }

        //TODO: Change the below so that it loads the DisplayResults view, passing in the model
        return View();
        
    }
    private List<TestQuestionModel> GetQuestionModels()
    {
        List<TestQuestionModel> questionModels = new List<TestQuestionModel>();
        foreach(var question in _Exam.Questions)
        {
            if(question.QuestionType == "TrueFalseQuestion")
            {
                TrueFalseQuestionModel tfQuestion = new TrueFalseQuestionModel();
                tfQuestion.ID = question.ID;
                tfQuestion.Question = question.Question;
                questionModels.Add(tfQuestion);
            }
            
            //TODO: Implement creating the rest of the question models here. Multiple choice questions will require setting the choices.
        }
        return questionModels;
    }
}