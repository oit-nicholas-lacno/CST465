﻿namespace Lab8.DataObjects
{
    public class ImageObject
    {
    }
}
